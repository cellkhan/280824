/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho_202;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 *
 * @author pablo
 */

@SpringBootApplication
public class Trabalho_202 {

    public static void main(String[] args) {
        SpringApplication.run(Trabalho_202.class, args);
        System.out.println("Verificando se o programa passou por aqui!");
    }
}
